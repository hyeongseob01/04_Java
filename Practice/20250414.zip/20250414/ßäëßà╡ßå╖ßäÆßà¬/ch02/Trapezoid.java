package workout.day_20250415.심화;

public class Trapezoid {

  public static void main(String[] args) {
    int x = 5;
    int height = 7;
    int width = 10;
    float sum = (x+width)*height/2;

    System.out.printf("%10f",sum);
  }
}
