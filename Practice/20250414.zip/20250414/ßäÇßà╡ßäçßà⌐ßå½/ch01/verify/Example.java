package ch01.verify;

public class Example {
    public static void main(String[] args) {
        System.out.println("개발자가 되기 위한 필수 개발 언어 Java");
    }
}
