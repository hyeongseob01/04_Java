package ch01.sec10;

public class Calculator {
    
}
