package ch01.sec09;

public class Hello {
    public static void main(String[] args) {
        System.out.println("Hello, java");
    }
}
