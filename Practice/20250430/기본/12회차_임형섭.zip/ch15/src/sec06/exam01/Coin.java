package sec06.exam01;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor

public class Coin {
    private int value;

    public int getValue() {
        return value;
    }
}
