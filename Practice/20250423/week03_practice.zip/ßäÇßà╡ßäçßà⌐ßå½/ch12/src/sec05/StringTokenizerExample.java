package sec05;

import java.util.StringTokenizer;

public class StringTokenizerExample {
    public static void main(String[] args) {
        String data1 = "홍길동&이수홍,박연수";
        String data2 = "홍길동/이수홍/박연수";
        String[] name1 = data1.split("&|,");
        for(String name : name1) {
            System.out.println(name);
        }
        System.out.println();
        StringTokenizer name2 = new StringTokenizer(data2,"/");
        while(name2.hasMoreTokens()) {
            System.out.println(name2.nextToken());
        }
    }
}
