package sec08;

import java.util.*;

public class CalendarExample {
    public static void main(String[] args) {
        Calendar cal = Calendar.getInstance();
        int year = cal.get(Calendar.YEAR);
        int month = cal.get(Calendar.MONTH);
        int day = cal.get(Calendar.DAY_OF_MONTH);
        System.out.println(year+"년 "+month+"월 "+day + "일");

        int week = cal.get(Calendar.DAY_OF_WEEK);
            String weekStr = switch (week) {
                case Calendar.SUNDAY -> "일요일";
                case Calendar.MONDAY -> "월요일";
                case Calendar.TUESDAY -> "화요일";
                case Calendar.WEDNESDAY -> "수요일";
                case Calendar.THURSDAY -> "목요일";
                case Calendar.FRIDAY -> "금요일";
                case Calendar.SATURDAY -> "토요일";
                default -> "";
            };
        int amPm = cal.get(Calendar.AM_PM);
        String amPmStr = (amPm == Calendar.AM) ? "오전" : "오후";
        System.out.println(weekStr + " " + amPmStr);

        int hour = cal.get(Calendar.HOUR);
        int minute = cal.get(Calendar.MINUTE);
        int second = cal.get(Calendar.SECOND);
        System.out.println(hour + "시 " + minute + "분 " + second + "초");
        }
    }

