package sec04;

import java.util.Properties;
import java.util.Set;

public class GetPropertyExample {
    public static void main(String[] args) {
        Properties props = System.getProperties();
        String osName = props.getProperty("os.name");
        System.out.println("운영체제 이름: " + osName);
        String userName = props.getProperty("user.name");
        String userHome = props.getProperty("user.home");
        System.out.println("사용자 이름: " + userName);
        System.out.println("홈 디렉토리: " + userHome);
        System.out.println();
        Set<String> propertyNames = props.stringPropertyNames();
        for (String name : propertyNames) {
            String value = props.getProperty(name);
            System.out.println(name + " = " + value);
        }
    }
}
