package sec02.exam01;

public class ExceptionHandlingExample1 {
    public static void printLength(String data){
        int result = data.length();
        System.out.println("문자 수: "+result);
    }

    public static void main(String[] args) {
        try{System.out.println("[프로그램 시작]\n");
        printLength("ThisIsJava");
        printLength(null);
        System.out.println("[프로그램 종료]");}
        catch(Exception e){
            System.out.println("data를 입력해주세요.");
        }
    }
}
///opt/homebrew/Cellar/openjdk@17/17.0.15/libexec/openjdk.jdk/Contents/Home/bin/java -javaagent:/Applications/IntelliJ IDEA.app/Contents/lib/idea_rt.jar=49800 -Dfile.encoding=UTF-8 -classpath /Users/imhyeongseob/Documents/KB_fullstack/03_Java/Practice/20250423/기본/ch11/out/production/ch11 sec02.exam01.ExceptionHandlingExample1
//Exception in thread "main" java.lang.NullPointerException: Cannot invoke "String.length()" because "data" is null
//	at sec02.exam01.ExceptionHandlingExample1.printLength(ExceptionHandlingExample1.java:5)
//	at sec02.exam01.ExceptionHandlingExample1.main(ExceptionHandlingExample1.java:12)

// 이런 오류가 뜨듯이, String data값이 null일때, 즉 주소값이 할당되어있지 않을때 예외처리를 진행하지 않아서 오류가 발생하게 된다 !!
