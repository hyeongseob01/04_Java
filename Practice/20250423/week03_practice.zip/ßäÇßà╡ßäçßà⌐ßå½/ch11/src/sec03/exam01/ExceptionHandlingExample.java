package sec03.exam01;

public class ExceptionHandlingExample {
    public static void main(String[] args) {
        String[] array = {"100", "1oo"};
        try{
        for(int i =0; i<array.length; i++) {
            int value = Integer.parseInt(array[i]);
            System.out.println("array[" + i + "] = " + value);
        }
        }catch(NumberFormatException e) {
            System.out.println("NumberFormatException");
        }catch(ArrayIndexOutOfBoundsException e) {
            System.out.println("ArrayIndexOutOfBoundsException");
        }catch (Exception e) {
            System.out.println("Exception");
        }
    }
}
