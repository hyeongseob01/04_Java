package sec03.exam03;

public class ExceptionHandlingExample {
    public static void main(String[] args) {
        String[] array = {"100", "1oo", null, "200"};
        try {
            for (int i = 0; i < array.length; i++) {
                int value = Integer.parseInt(array[i]);
                System.out.println("array[" + i + "] = " + value);
            }
        }catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("ArrayIndexOutOfBoundsException");
        }catch (NullPointerException | NumberFormatException e){
            System.out.println("NullPointerException Or NumberFormatException");
        }catch (Exception e) {
            System.out.println("Exception");
        }
    }
}
